import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Enemy extends Actor
{
    int health =0;
    public Enemy(int hp)
    {
        health = hp;
    }
    /**
     * Act - do whatever the Enemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
    } 
    public void loseHealth()
    {
     health--;   
    }
    public void moveEnemy()
    {
        move(-Greenfoot.getRandomNumber(7));
    }
    public void Health()
    {
     loseHealth();
    }
    public void ifOnTop()
    {
        Actor Hero = getOneIntersectingObject(Hero.class);
        
        if (getOneObjectAtOffset(-19, -45, Hero.class) != null || getOneObjectAtOffset(19, -45, Hero.class) != null) 
       {  
           getWorld().removeObject(this);  
       } 
       else if(getOneObjectAtOffset(-19, 10, Hero.class) != null || getOneObjectAtOffset(19, 10, Hero.class) != null )
       {  
            Hero.die();
       }
    }
}

